package com.scatterbrain.sniles;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {
    private final List<Event> eventList; // List to store the events
    // Interface for handling edit button clicks
    private final OnEditButtonClickListener editButtonClickListener;

    // Constructor
    public EventAdapter(List<Event> eventList, OnEditButtonClickListener editButtonClickListener) {
        this.eventList = eventList;
        this.editButtonClickListener = editButtonClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the layout for an event item
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // Get event at the current position
        Event event = eventList.get(position);

        // Bind event data to the view holder
        holder.name.setText(event.getName());
        holder.dateTime.setText(event.getDateTime());
        holder.location.setText(event.getLocation());
        holder.description.setText(event.getDescription());

        // Set listener for edit button
        holder.editButton.setOnClickListener(
                v -> editButtonClickListener.onEditButtonClick(position));
    }

    @Override
    public int getItemCount() {
        return eventList.size(); // Return the size of the event list
    }

    // Interface to handle edit button clicks
    public interface OnEditButtonClickListener {
        void onEditButtonClick(int position);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView name, dateTime, location, description;
        public Button editButton;

        public ViewHolder(View view) {
            super(view);
            // Find views by their IDs
            name = view.findViewById(R.id.eventName);
            dateTime = view.findViewById(R.id.eventDate);
            location = view.findViewById(R.id.eventLocation);
            description = view.findViewById(R.id.eventDescription);
            editButton = view.findViewById(R.id.editButton);
        }
    }
}
