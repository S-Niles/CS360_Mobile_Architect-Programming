package com.scatterbrain.sniles;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EventAdapter eventAdapter;
    private List<Event> eventList;
    private DatabaseHelper databaseHelper;
    private static final int SMS_PERMISSION_CODE = 1;
    private static final String PREFS_NAME = "MyPrefs";
    private static final String FIRST_LOGIN_KEY = "first_login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check for first login and request SMS permission if necessary
        if (isFirstTimeLogin()) {
            requestSmsPermission();
        }

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Configure UI elements
        Button addEventButton = findViewById(R.id.addEvent);
        Button homeButton = findViewById(R.id.homeButton);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventList = databaseHelper.getAllEvents();
        eventAdapter = new EventAdapter(eventList, this::showEditEventDialog);
        recyclerView.setAdapter(eventAdapter);
        addEventButton.setOnClickListener(v -> addEvent());
        homeButton.setOnClickListener(v -> goToHome());
    }

    // Method to check if this is the user's first login
    private boolean isFirstTimeLogin() {
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        if (settings.contains(FIRST_LOGIN_KEY)) {
            return false;
        }
        SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean(FIRST_LOGIN_KEY, true);
        editor.apply();
        return true;
    }

    // Request the SEND_SMS permission from the user
    private void requestSmsPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Handle the user's response to the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE && grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Function to send an SMS alert
    private void sendSmsAlert(String phoneNumber, String message) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(getApplicationContext(), "SMS Sent!", Toast.LENGTH_LONG).show();
        }
    }

    // Function to add a new event
    private void addEvent() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.activity_event_edit, null);
        dialogBuilder.setView(dialogView);
        EditText eventNameInput = dialogView.findViewById(R.id.editEventName);
        EditText eventDateInput = dialogView.findViewById(R.id.editEventDate);
        EditText eventLocationInput = dialogView.findViewById(R.id.editEventLocation);
        EditText eventDescriptionInput = dialogView.findViewById(R.id.editEventDescription);
        Button addButton = dialogView.findViewById(R.id.saveButton);
        addButton.setOnClickListener(v -> {
            String name = eventNameInput.getText().toString();
            String dateTime = eventDateInput.getText().toString();
            String location = eventLocationInput.getText().toString();
            String description = eventDescriptionInput.getText().toString();
            Event event = new Event(0, name, dateTime, location, description);
            if (databaseHelper.createEvent(event)) {
                eventList = databaseHelper.getAllEvents();
                int newPosition = eventList.size() - 1;
                eventAdapter.notifyItemInserted(newPosition);
                Toast.makeText(this, "Event added!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to add event.", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }

    // Function to navigate to home (needs to be implemented)
    private void goToHome() {
        // TODO: Logic to navigate to home.
    }

    // Function to show edit event dialog
    private void showEditEventDialog(int position) {
        Event event = eventList.get(position);
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.activity_event_edit, null);
        dialogBuilder.setView(dialogView);
        final EditText editEventName = dialogView.findViewById(R.id.editEventName);
        final EditText editEventDate = dialogView.findViewById(R.id.editEventDate);
        final EditText editEventTime = dialogView.findViewById(R.id.editEventTime);
        final EditText editEventLocation = dialogView.findViewById(R.id.editEventLocation);
        final EditText editEventDescription = dialogView.findViewById(R.id.editEventDescription);

        editEventName.setText(event.getName());
        String[] dateTimeParts = event.getDateTime().split(" ");
        editEventDate.setText(dateTimeParts[0]);
        editEventTime.setText(dateTimeParts[1]);
        editEventLocation.setText(event.getLocation());
        editEventDescription.setText(event.getDescription());

        dialogBuilder.setTitle("Edit Event");
        dialogBuilder.setPositiveButton("Save", (dialog, whichButton) -> {
            event.setName(editEventName.getText().toString());
            event.setDateTime(editEventDate.getText().toString() + " " + editEventTime.getText().toString());
            event.setLocation(editEventLocation.getText().toString());
            event.setDescription(editEventDescription.getText().toString());
            databaseHelper.updateEvent(event);
            eventAdapter.notifyItemChanged(position);
        });
        dialogBuilder.setNegativeButton("Cancel", (dialog, whichButton) -> {
            // User cancelled the dialog
        });
        AlertDialog b = dialogBuilder.create();
        b.show();
    }
}
