package com.scatterbrain.sniles;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Constants for database and table names
    private static final String DATABASE_NAME = "event_manager.db";
    private static final String TABLE_EVENTS = "events";
    private static final String TABLE_USERS = "users";

    // Constants for events table columns
    private static final String COL_EVENT_ID = "event_id";
    private static final String COL_EVENT_NAME = "name";
    private static final String COL_EVENT_DATETIME = "dateTime";
    private static final String COL_EVENT_LOCATION = "location";
    private static final String COL_EVENT_DESCRIPTION = "description";

    // Constants for users table columns
    private static final String COL_USER_ID = "user_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creating events table
        String createEventsTableQuery = "CREATE TABLE " + TABLE_EVENTS + " ("
                + COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_EVENT_NAME + " TEXT, " + COL_EVENT_DATETIME + " TEXT, "
                + COL_EVENT_LOCATION + " TEXT, " + COL_EVENT_DESCRIPTION + " TEXT)";
        db.execSQL(createEventsTableQuery);

        // Creating users table
        String createUsersTableQuery = "CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE, " + COL_PASSWORD + " TEXT)";
        db.execSQL(createUsersTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Dropping existing tables and re-creating them
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Create a new event
    public boolean createEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_NAME, event.getName());
        values.put(COL_EVENT_DATETIME, event.getDateTime());
        values.put(COL_EVENT_LOCATION, event.getLocation());
        values.put(COL_EVENT_DESCRIPTION, event.getDescription());

        long result = db.insert(TABLE_EVENTS, null, values);
        return result != -1;
    }

    // Retrieve all events
    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EVENTS, null);

        if (cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(COL_EVENT_ID);
                int nameIndex = cursor.getColumnIndex(COL_EVENT_NAME);
                int dateTimeIndex = cursor.getColumnIndex(COL_EVENT_DATETIME);
                int locationIndex = cursor.getColumnIndex(COL_EVENT_LOCATION);
                int descriptionIndex = cursor.getColumnIndex(COL_EVENT_DESCRIPTION);

                // Check for invalid indices and skip row if found
                if (idIndex == -1 || nameIndex == -1 ||
                    dateTimeIndex == -1 || locationIndex == -1 ||
                        descriptionIndex == -1) {
                    continue;
                }

                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                String dateTime = cursor.getString(dateTimeIndex);
                String location = cursor.getString(locationIndex);
                String description = cursor.getString(descriptionIndex);
                events.add(new Event(id, name, dateTime, location, description));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return events;
    }

    // Update an existing event
    public boolean updateEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_NAME, event.getName());
        values.put(COL_EVENT_DATETIME, event.getDateTime());
        values.put(COL_EVENT_LOCATION, event.getLocation());
        values.put(COL_EVENT_DESCRIPTION, event.getDescription());

        int result = db.update(TABLE_EVENTS,
                               values,
                     COL_EVENT_ID + " = ?",
                               new String[]{String.valueOf(event.getId())});
        return result > 0;
    }

    // Delete an event by ID
    public boolean deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_EVENTS,
                     COL_EVENT_ID + " = ?",
                               new String[]{String.valueOf(eventId)});
        return result > 0;
    }

    // Retrieve a specific event by ID
    public Event getEvent(long eventId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EVENTS,
                         null,
                         COL_EVENT_ID + " = ?",
                                 new String[]{String.valueOf(eventId)},
                         null,
                          null,
                         null);

        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex(COL_EVENT_ID);
            int nameIndex = cursor.getColumnIndex(COL_EVENT_NAME);
            int dateTimeIndex = cursor.getColumnIndex(COL_EVENT_DATETIME);
            int locationIndex = cursor.getColumnIndex(COL_EVENT_LOCATION);
            int descriptionIndex = cursor.getColumnIndex(COL_EVENT_DESCRIPTION);

            // Check for invalid indices and return null if found
            if (idIndex == -1 || nameIndex == -1 ||
                dateTimeIndex == -1 || locationIndex == -1 ||
                descriptionIndex == -1) {

                cursor.close();
                return null;
            }

            int id = cursor.getInt(idIndex);
            String name = cursor.getString(nameIndex);
            String dateTime = cursor.getString(dateTimeIndex);
            String location = cursor.getString(locationIndex);
            String description = cursor.getString(descriptionIndex);
            cursor.close();
            return new Event(id, name, dateTime, location, description);
        }
        return null;
    }

    // Validate user credentials
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                         null,
                         COL_USERNAME + " = ?",
                                 new String[]{username},
                         null,
                          null,
                         null);

        if (cursor != null && cursor.moveToFirst()) {
            int passwordIndex = cursor.getColumnIndex(COL_PASSWORD);

            // Check for invalid password index and return false if found
            if (passwordIndex == -1) {
                cursor.close();
                return false;
            }

            String storedPassword = cursor.getString(passwordIndex);
            cursor.close();
            return password.equals(storedPassword);
        }
        return false;
    }

    // Add a new user
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }
}
