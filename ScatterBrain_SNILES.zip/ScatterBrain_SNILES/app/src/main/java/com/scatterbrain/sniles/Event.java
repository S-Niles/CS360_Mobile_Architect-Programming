package com.scatterbrain.sniles;

public class Event {
    private int id;             // Event's ID (for internal use)
    private String name;        // Event's name
    private String dateTime;    // Event's date and time combined in "YYYY-MM-DD HH:MM" format
    private String location;    // Event's location
    private String description; // Event's description

    // Constructor to initialize all the fields
    public Event(int id, String name, String dateTime, String location, String description) {
        this.id = id;
        this.name = name;
        this.dateTime = dateTime;
        this.location = location;
        this.description = description;
    }

    // Getters and setters for all fields
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDateTime() { return dateTime; }
    public void setDateTime(String dateTime) { this.dateTime = dateTime; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
