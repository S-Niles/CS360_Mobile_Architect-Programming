package com.scatterbrain.sniles;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        dbHelper = new DatabaseHelper(this); // Initialize database helper

        // Connect UI elements
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Set listener for login button
        loginButton.setOnClickListener(v -> login());

        // Set listener for create account button (opens a dialog for registration)
        createAccountButton.setOnClickListener(v -> openRegistrationDialog());
    }

    // Method for handling user login
    private void login() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        } else if (dbHelper.validateUser(username, password)) {
            // Successful login, navigate to MainActivity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(LoginActivity.this, "Invalid login credentials", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to open the registration dialog
    private void openRegistrationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
        View view = getLayoutInflater().inflate(R.layout.activity_register, null);

        final EditText dialogUsernameEditText = view.findViewById(R.id.dialogUsernameEditText);
        final EditText dialogPasswordEditText = view.findViewById(R.id.dialogPasswordEditText);
        Button registerButton = view.findViewById(R.id.registerButton);

        builder.setView(view);
        final AlertDialog dialog = builder.create();
        dialog.show();

        // Listener for the register button inside the dialog
        registerButton.setOnClickListener(v -> {
            String username = dialogUsernameEditText.getText().toString().trim();
            String password = dialogPasswordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else if (dbHelper.addUser(username, password)) {
                Toast.makeText(LoginActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                dialog.dismiss(); // Close the dialog when done
            } else {
                Toast.makeText(LoginActivity.this, "Registration failed. Username may already be taken.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
