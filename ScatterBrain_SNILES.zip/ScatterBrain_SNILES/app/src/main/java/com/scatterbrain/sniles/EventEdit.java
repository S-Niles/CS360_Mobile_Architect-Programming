package com.scatterbrain.sniles;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EventEdit extends AppCompatActivity {
    // Define the required fields
    private EditText editEventName, editEventDate, editEventTime,
            editEventLocation, editEventDescription;
    private Button saveButton;
    private DatabaseHelper databaseHelper;
    private Event event;
    private long eventId;
    private int dayOfMonth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);
        eventId = getIntent().getLongExtra("EVENT_ID", -1);
        databaseHelper = new DatabaseHelper(this);
        initUIComponents(); // Initialize the UI components
        setupDateTimePickers(); // Set up date and time pickers
        saveButton.setOnClickListener(this::saveEvent); // Save button click listener
    }

    // Function to initialize the UI components
    private void initUIComponents() {
        // Retrieve views by their IDs and set initial values
        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editEventLocation = findViewById(R.id.editEventLocation);
        editEventDescription = findViewById(R.id.editEventDescription);
        saveButton = findViewById(R.id.saveButton);

        event = databaseHelper.getEvent(eventId); // Retrieve the event from the database
        String dateTime = event.getDateTime();
        editEventName.setText(event.getName());
        editEventDate.setText(dateTime.split(" ")[0]);
        editEventTime.setText(dateTime.split(" ")[1]);
        editEventLocation.setText(event.getLocation());
        editEventDescription.setText(event.getDescription());
    }

    // Function to set up the date and time pickers
    private void setupDateTimePickers() {
        final Calendar myCalendar = Calendar.getInstance();
        final DatePickerDialog.OnDateSetListener date = (view, year, month, day) -> {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, month);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            editEventDate.setText(sdf.format(myCalendar.getTime()));
        };

        // Click listeners for date and time pickers
        editEventDate.setOnClickListener(v -> new DatePickerDialog(EventEdit.this, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show());

        editEventTime.setOnClickListener(v -> {
            int hour = myCalendar.get(Calendar.HOUR_OF_DAY);
            int minute = myCalendar.get(Calendar.MINUTE);
            TimePickerDialog mTimePicker = new TimePickerDialog(EventEdit.this,
                    (timePicker, selectedHour, selectedMinute) -> {
                        String formattedMinute = (selectedMinute < 10)
                                ? "0" + selectedMinute : String.valueOf(selectedMinute);
                        editEventTime.setText(selectedHour + ":" + formattedMinute);
                    }, hour, minute, true);
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        });
    }

    // Function to save the edited event
    private void saveEvent(View view) {
        // Combine date and time, set updated values, and update the event in the database
        String dateTime = editEventDate.getText().toString() + " " + editEventTime.getText().toString();
        event.setName(editEventName.getText().toString());
        event.setDateTime(dateTime);
        event.setLocation(editEventLocation.getText().toString());
        event.setDescription(editEventDescription.getText().toString());

        if (databaseHelper.updateEvent(event)) {
            Toast.makeText(this, "Event updated successfully!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error updating event!", Toast.LENGTH_SHORT).show();
        }
    }
}
